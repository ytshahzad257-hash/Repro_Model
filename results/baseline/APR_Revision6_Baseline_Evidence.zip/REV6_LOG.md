# Revision 6 work log

Started 18 October 2026 (Asia/Karachi).

## Authorization and scope

The user requested completion of Revision 6 and then selected all experiments A, B, C and D. No commit, push, tag, PR publication or other release action is authorized until the final diff is shown and the user explicitly says yes. Zenodo/DOI steps remain manual. Author manuscript and artifact semantics will not be edited until the requested baseline passes.

## Baseline setup

- Extracted APR_Revision5_1.zip in the requested LLM paper folder.
- Read the response, change review, experiment designs, manuscript, formal model, assumptions and changelog.
- Cloned public main into ../repo and created branch revision6; applied Repro_Model_revision5_1.patch.
- Patch comparison: all source files match the supplied artifact. Ten ignored legacy figures/generated preview files were omitted by the patch. Copied those exact files from the supplied artifact as setup; no semantic/source correction made.
- Installed the artifact editable with dev extras into an isolated Python 3.12.14 environment.
- Unchanged baseline: python -m pytest -q -> 31 passed in 0.71 seconds.
- Full baseline driver with Java 21.0.12.1+1 and TLC 2026.10.15.145915: running; no implementation edits yet.

## Release caveats

A clean committed reproduction and git_dirty:false cannot truthfully be claimed before the user approves the commit. The final preapproval package will identify this pending release step explicitly.

## Baseline outcome: STOPPED as requested

The full baseline driver returned failure. No manuscript/model-source revisions or new experiments were implemented.

| Check | Actual outcome |
| --- | --- |
| Unit tests | 31 passed (standalone 0.71 s; driver 0.69 s). |
| Python model, sufficiency, bounds, quarantine, figures | Passed. |
| TLC matrix | 196 jobs launched; both IgnoreInfoChecks/K4 single-copy invariant runs exhausted the reviewer's 512 MB maximum Java heap (about 455 MB usable heap). Other compared counts/values match. |
| Explicit cross_checkers.py | FAIL: 308 compared quantities; one additional tlc_run_validity failure for IgnoreInfoChecks/K4. No value mismatch among the 308 quantities. |
| Explicit check_expected.py | All expected values match. |
| Paper-table generator | Fails at its assertion that cross-check status must be PASS. |
| Full driver | Failed. The step labelled Python/TLC cross-check incorrectly says PASS even though its last line is FAIL 308 1, because cross_checkers.py exits zero on a failed result. This is a separate reporting defect to repair after resumption. |

The TLC logs explicitly say Java ran out of memory. This does not establish a model disagreement or invalidate the reported counts. The conservative heap setting was introduced by this review run, not supplied by the authors. A retry with a larger heap and fewer concurrent TLC jobs is the appropriate next diagnostic, but has NOT been performed because the request says to stop on any baseline difference.

### Commands executed

Commands used the isolated Python 3.12.14 interpreter at `/Users/muneer/Documents/Codex/2026-10-18/do-x20/work/env313/bin/python` and portable Java on PATH.

1. `git clone https://github.com/ytshahzad257-hash/Repro_Model.git repo`
2. `git checkout -b revision6`
3. `git apply ../APR_Revision5_1/Repro_Model_revision5_1.patch`
4. `python -m pip install -e '.[dev]'`
5. `python -m pytest -q`
6. `TLA2TOOLS_JAR=/Users/muneer/Documents/Codex/2026-10-18/do-x20/work/tla2tools.jar JAVA_TOOL_OPTIONS=-Xmx512m python -u experiments/run_all.py`
7. `python scripts/make_tables.py <isolated-diagnostic-output>` (to capture the failure traceback, without changing manuscript tables)
8. `python scripts/cross_checkers.py` -> FAIL 308 1
9. `python scripts/check_expected.py` -> all expected values match

Baseline-generated outputs changed in the working clone as a consequence of the reproduction commands. The supplied extracted Revision 5.1 package, author manuscript, and model source remain unchanged. No commits, pushes, tags, PRs or publication actions occurred.

### Next action after the user's direction

Retry the unchanged TLC matrix with `JAVA_TOOL_OPTIONS=-Xmx2g` and `python scripts/tlc_matrix.py --jobs 2`, then repeat the cross-check, expected-value regression and table generation. Preserve this failed run rather than overwrite its evidence. Once the baseline is accepted, repair the exit-status reporting defect and proceed through the requested F1-F14 audit and all experiments A-D.

### Environment preparation completed before the stop

Portable Ollama and TinyTeX/TeX Live archives were downloaded to the task workspace. No model server was started, no model was downloaded, and no API key was configured or exposed. Docker, a system TeX installation and a pre-existing Ollama service were not found. These are setup observations, not experiment results.
